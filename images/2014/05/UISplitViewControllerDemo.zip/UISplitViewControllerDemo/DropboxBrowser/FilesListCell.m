//
//  FilesListCell.m
//  DropboxBrowser
//
//  Created by Nikola Sobadjiev on 4/24/13.
//  Copyright (c) 2013 Nikola Sobadjiev. All rights reserved.
//

#import "FilesListCell.h"

static NSString* const k_defaultImageName = @"defaultThumbnail.png";

@implementation FilesListCell

@synthesize thumbnailPath;
@synthesize defaultThumbnail;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.defaultThumbnail = [UIImage imageNamed:k_defaultImageName];
        //self.thumbnailPath = nil;
    }
    return self;
}

- (void)dealloc
{
    self.defaultThumbnail = nil;
    self.thumbnailPath = nil;
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)setDefaultThumbnail:(UIImage *)_defaultThumbnail
{
    self.imageView.image = _defaultThumbnail;
}

- (void)setItemName:(NSString*)name
{
    self.textLabel.text = name;
}

- (void)setItemDescription:(NSString*)description
{
    self.detailTextLabel.text = description;
}


@end
