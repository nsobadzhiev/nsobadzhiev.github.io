//
//  DetailViewController.h
//  DropboxBrowser
//
//  Created by Nikola Sobadjiev on 4/24/13.
//  Copyright (c) 2013 Nikola Sobadjiev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController <UISplitViewControllerDelegate>
{
    IBOutlet UIImageView* imageView;                    // the image view containing the image downloaded for this file
    IBOutlet UIActivityIndicatorView* activityIndicator;// an activity indicator shown during the image download
}

@property (nonatomic, retain) UIImage* image;

@end
