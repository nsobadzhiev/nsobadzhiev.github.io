//
//  FileData.m
//  DropboxBrowser
//
//  Created by Nikola Sobadjiev on 4/25/13.
//  Copyright (c) 2013 Nikola Sobadjiev. All rights reserved.
//

#import "FileData.h"

@implementation FileData

@end
