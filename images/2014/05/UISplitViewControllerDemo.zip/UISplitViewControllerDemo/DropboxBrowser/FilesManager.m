//
//  DropboxFilesManager.m
//  DropboxBrowser
//
//  Created by Nikola Sobadjiev on 4/25/13.
//  Copyright (c) 2013 Nikola Sobadjiev. All rights reserved.
//

#import "FilesManager.h"
#import "FileData.h"


@implementation FilesManager

@synthesize filesArray;

- (NSArray*)filesArray
{
    FileData* pagesFileData = [[FileData alloc] init];
    pagesFileData.fileName = @"Pages";
    pagesFileData.fileThumbnail = [UIImage imageNamed:@"pages"];
    pagesFileData.fileImage = [UIImage imageNamed:@"pages_XL"];
    
    FileData* powerpointFileData = [[FileData alloc] init];
    powerpointFileData.fileName = @"Presentation";
    powerpointFileData.fileThumbnail = [UIImage imageNamed:@"powerpoint"];
    powerpointFileData.fileImage = [UIImage imageNamed:@"powerpoint_XL"];
    
    FileData* docFileData = [[FileData alloc] init];
    docFileData.fileName = @"Document";
    docFileData.fileThumbnail = [UIImage imageNamed:@"word"];
    docFileData.fileImage = [UIImage imageNamed:@"word_XL"];
    
    FileData* textFileData = [[FileData alloc] init];
    textFileData.fileName = @"Text";
    textFileData.fileThumbnail = [UIImage imageNamed:@"text"];
    textFileData.fileImage = [UIImage imageNamed:@"text_XL"];
    return [NSArray arrayWithObjects:pagesFileData, powerpointFileData, docFileData, textFileData, nil];
}

@end
