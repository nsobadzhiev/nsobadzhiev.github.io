//
//  MasterViewController.m
//  DropboxBrowser
//
//  Created by Nikola Sobadjiev on 4/24/13.
//  Copyright (c) 2013 Nikola Sobadjiev. All rights reserved.
//

#import "FileListViewController.h"
#import "DetailViewController.h"
#import "FilesListCell.h"
#import "FileData.h"

@interface FileListViewController (PrivateMethods)

// showing / hiding the activity indicator
- (void)displayLoadingScreen;
- (void)removeLoadingScreen;

// shows an alert view if the JSON cannot be loaded
- (void)showDownloadError:(NSError*)error;

@end

@implementation FileListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"File list", @"File list");
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            self.clearsSelectionOnViewWillAppear = NO;
            self.contentSizeForViewInPopover = CGSizeMake(320.0, 600.0);
        }
        filesManager = [[FilesManager alloc] init];
    }
    return self;
}
							
- (void)dealloc
{
    [_detailViewController release];
    [filesManager release];
    [loadingScreen release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewDidAppear:(BOOL)animated
{
    if (filesManager.filesArray == nil)
    {
        // if filesArray is empty, this means that
        // the files haven't been fetched yet
        [self displayLoadingScreen];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[filesManager filesArray] count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* CellIdentifier = @"FileCell";
    
    FilesListCell* cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[[FilesListCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                     reuseIdentifier:CellIdentifier] autorelease];
        
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        {
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
    }


    FileData* file = (FileData*)[[filesManager filesArray] objectAtIndex:indexPath.row];
    [cell setItemName:file.fileName];
    [cell setItemDescription:file.fileDescription];
    [[cell imageView] setImage:file.fileThumbnail];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FileData* file = (FileData*)[[filesManager filesArray] objectAtIndex:indexPath.row];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
	    if (!self.detailViewController)
        {
	        self.detailViewController = [[[DetailViewController alloc] initWithNibName:@"DetailViewController_iPhone" bundle:nil] autorelease];
	    }
        
	    self.detailViewController.image = file.fileImage;
        [self.navigationController pushViewController:self.detailViewController animated:YES];
    }
    else
    {
        self.detailViewController.image = file.fileImage;
    }
}

#pragma mark DropboxFilesManagerDelegate

- (void)dropboxFileManager:(FilesManager*)manager
             didParseFiles:(NSArray*)files
{
    [self.tableView reloadData];
    [self removeLoadingScreen];
}

- (void)dropboxFileManager:(FilesManager*)manager
          didFailWithError:(NSError*)error
{
    [self removeLoadingScreen];
    [self showDownloadError:error];
}

#pragma mark PrivateMethods

- (void)displayLoadingScreen
{
    if (!loadingScreen)
    {
        CGRect screenRect = [[UIScreen mainScreen] bounds];
        loadingScreen = [[UIView alloc] initWithFrame:screenRect];
        loadingScreen.backgroundColor = [UIColor blackColor];
        loadingScreen.alpha = 0.5f;
        loadingScreen.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
        UIActivityIndicatorView* activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        activityIndicator.center = CGPointMake(screenRect.size.width / 2, screenRect.size.height / 2);
        [loadingScreen addSubview:activityIndicator];
        [activityIndicator startAnimating];
    }
    [[[UIApplication sharedApplication] keyWindow] addSubview:loadingScreen];
}

- (void)removeLoadingScreen
{
    [loadingScreen removeFromSuperview];
}

- (void)showDownloadError:(NSError*)error
{
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Download failed", @"Download failed")
                                                    message:error.localizedFailureReason
                                                   delegate:nil
                                          cancelButtonTitle:NSLocalizedString(@"OK", @"OK")
                                          otherButtonTitles:nil];
    [alert show];
    [alert release];
}

@end
