//
//  FileData.h
//  DropboxBrowser
//
//  Created by Nikola Sobadjiev on 4/25/13.
//  Copyright (c) 2013 Nikola Sobadjiev. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileData : NSObject

@property (nonatomic, retain) NSString* fileName;
@property (nonatomic, retain) NSString* fileDescription;
@property (nonatomic, retain) UIImage* fileThumbnail;
@property (nonatomic, retain) UIImage* fileImage;

@end
