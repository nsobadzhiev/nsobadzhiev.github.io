//
//  FilesListCell.h
//  DropboxBrowser
//
//  Created by Nikola Sobadjiev on 4/24/13.
//  Copyright (c) 2013 Nikola Sobadjiev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FilesListCell : UITableViewCell
{
    NSString*           thumbnailPath;
    UIImage*            defaultThumbnail;
}

@property (nonatomic, retain) NSString* thumbnailPath;
@property (nonatomic, retain) UIImage*  defaultThumbnail;

- (void)setItemName:(NSString*)name;
- (void)setItemDescription:(NSString*)description;

@end
