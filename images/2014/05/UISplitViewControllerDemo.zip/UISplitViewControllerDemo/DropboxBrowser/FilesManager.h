//
//  DropboxFilesManager.h
//  DropboxBrowser
//
//  Created by Nikola Sobadjiev on 4/25/13.
//  Copyright (c) 2013 Nikola Sobadjiev. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FilesManager : NSObject
{
    NSArray* filesArray;            // an array containing FileData objects
}

@property (nonatomic, readonly) NSArray* filesArray;

@end
