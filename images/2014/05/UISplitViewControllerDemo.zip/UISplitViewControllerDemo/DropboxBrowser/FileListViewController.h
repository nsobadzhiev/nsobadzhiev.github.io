//
//  MasterViewController.h
//  DropboxBrowser
//
//  Created by Nikola Sobadjiev on 4/24/13.
//  Copyright (c) 2013 Nikola Sobadjiev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FilesManager.h"

@class DetailViewController;

@interface FileListViewController : UITableViewController
{
    UIView*                 loadingScreen;      // a view showing an activity indicator while the JSON
                                                // is being downloaded
    FilesManager*    filesManager;              // filesManager takes care of loading the JSON
                                                // containing file's metadata
}

@property (strong, nonatomic) DetailViewController *detailViewController;

@end
