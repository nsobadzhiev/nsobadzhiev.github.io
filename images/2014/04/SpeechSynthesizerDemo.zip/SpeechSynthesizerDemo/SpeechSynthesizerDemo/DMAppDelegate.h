//
//  DMAppDelegate.h
//  SpeechSynthesizerDemo
//
//  Created by Nikola Sobadjiev on 4/25/14.
//  Copyright (c) 2014 Nikola Sobadjiev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
