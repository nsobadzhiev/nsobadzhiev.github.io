//
//  DMViewController.h
//  SpeechSynthesizerDemo
//
//  Created by Nikola Sobadjiev on 4/25/14.
//  Copyright (c) 2014 Nikola Sobadjiev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface DMViewController : UIViewController
{
    IBOutlet UITextView* textView;
    IBOutlet UIButton* speakButton;
    IBOutlet UISlider* rateSlider;
    IBOutlet UISlider* pitchSlider;
    AVSpeechSynthesizer* mySynthesizer;
}

- (IBAction)onSpeakTap:(id)sender;

@end
