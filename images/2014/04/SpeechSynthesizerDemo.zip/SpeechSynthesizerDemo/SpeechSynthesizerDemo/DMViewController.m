//
//  DMViewController.m
//  SpeechSynthesizerDemo
//
//  Created by Nikola Sobadjiev on 4/25/14.
//  Copyright (c) 2014 Nikola Sobadjiev. All rights reserved.
//

#import "DMViewController.h"

@interface DMViewController ()

@end

@implementation DMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	mySynthesizer = [[AVSpeechSynthesizer alloc] init];
}

- (IBAction)onSpeakTap:(id)sender
{
    NSString* text = textView.text;
    float rate = rateSlider.value;
    float pitch = pitchSlider.value;
    AVSpeechUtterance* myTestUtterance = [[AVSpeechUtterance alloc] initWithString:text];
    myTestUtterance.rate = rate;
    myTestUtterance.pitchMultiplier = pitch;
    [mySynthesizer speakUtterance:myTestUtterance];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
